
#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
#include <functional>
#include <list>

using namespace std;

// common macros
#define UI unsigned int
#define UC unsigned char
#define FATAL (string)("Fatal Error")

// tokenizer.cpp
list<string> Tokenize(const char *sp);

// strmanip.cpp
void trim(string &s, const char T);

// construct string with generic x
template <typename T> string cons(T x)
{
	stringstream s;
	s << x;
	return s.str();
}
