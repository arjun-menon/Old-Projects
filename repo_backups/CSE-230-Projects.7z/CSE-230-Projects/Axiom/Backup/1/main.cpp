
#include "common.h"

void eval(const char *str)
{
	try
	{
		list<string> k = Tokenize(str);
		cout<<k.size()<<endl;
		for(list<string>::const_iterator i = k.begin(); i!=k.end(); i++)
		{
			cout<<*i<<endl;
		}
	}
	catch(string e)
	{
		cout<<e;
	}
}

int main()
{
	cout<<"AXIOM-REPL: "<<endl;

	for(string input; true; )
	{
		cout<<"\n> ";
		getline(cin, input);

		if(input=="quit")
			break;
		else
			eval(input.c_str());
	}

	return 0;
}
