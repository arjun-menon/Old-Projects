
#include "common.h"

// function prototypes (local)
inline void push_string(string &, list<string> &);
inline void fixChar(char &);

list<string> Tokenize(const char *sp)
{
	list<string> tokens;
	string temp;

	for(char c = *sp, prevChar = '\0' ; c ; c = *sp++ )
	{
		#define isBindingSymbol(C) ( C=='(' || C==')' || C=='{' || C=='}' )
		#define isAlphaNumeric(C) ( ((C>='0')&&(C<='9')) || (C>='A'&&C<='Z') || (C>='a'&&C<='z') )
		#define isPrintableASCII(C) ( ((C>=32)&&(C<=126)) || (C=='\t')  )

		if(isPrintableASCII(c))
		{
			if(isBindingSymbol(c))
			{
				push_string(temp, tokens);
				temp = c;
				push_string(temp, tokens);
			}
			else
			{
				fixChar(c);
				if(isAlphaNumeric(prevChar) != isAlphaNumeric(c))
					push_string(temp, tokens);
				temp += c;
				prevChar = c;
			}
		}

		#undef isBindingSymbol
		#undef isAlphaNumeric
		#undef isPrintableASCII

		else
			throw (string)("Non-printable ASCII character(" + cons((UC)(c)) 
				+ ":" + cons((UI)((UC)(c))) + ") detected.");
	}
	push_string(temp, tokens);

	return tokens;
}

inline void push_string(string &s, list<string> &l)
{
	trim(s, ' ');
	if(s.length())
		l.push_back(s);
	s = "";
}

inline void fixChar(char &c)
{
	// tab => space
	if(c=='\t')
		c = ' ';
	// ' => "
	else if(c=='\'')
		c = '\"';
	// newline => ;
	else if(c=='\n')
		c = ';';
}
