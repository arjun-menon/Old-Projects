
/**********************************.
| Common Standard Library Includes |
\**********************************/

#include <string>
#include <sstream>

// STL Containers
#include <vector>
#include <deque>
#include <list>
#include <map>

// C Library
#include <cmath>

using namespace std;

/**********************************************.
| Common Classes, templates, typedefs & macros |
\**********************************************/

// Common Classes
class genericException : public exception
{
	/*
	Normal Errors are due to the user's fault.
	Fatal Errors are due to the programmer's fault.
	*/
private:
	const string error_description;
public:
	genericException(string err_description, bool isFatal = false) : 
	error_description( (isFatal ? (string)("Fatal "):(string)("")) + (string)("Error: ") + err_description) {}
	genericException(genericException &copy) : error_description(copy.error_description) {}
	virtual const char* what() const throw() { return error_description.c_str(); }
};

// Common Templates
template <typename T> string cons(T x)
{
	// construct string with generic x
	stringstream s;
	s << x;
	return s.str();
}

// Common Macros
#define UI unsigned int
#define UC unsigned char
#define ASSERT(X) if(!(X)) throw genericException\
((string)("Assertion failure ( ")+(string)(#X)+(string)(" )"), true);

/*************************.
| Project Header Includes |
\*************************/

#include "datatypes.hpp"  // datatypes.cpp
#include "lexer.hpp"  // lexer.cpp
