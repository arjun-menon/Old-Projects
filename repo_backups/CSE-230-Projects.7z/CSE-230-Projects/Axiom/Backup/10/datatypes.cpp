
#include "common.hpp"

/*
==========
Datatypes:
==========
These datatypes are the building blocks of the language.
There are 7 primitive datatypes: 5 basic & 2 compound.
Except str & list, all primitives are immutable.
------
Basic:
------
null  - immutable ; Not a real dataType, represetned as a NULL pointer
byte  - immutable ; implemented using the C/C++ data type 'char'
int   - immutable ; implemented using the C/C++ data type 'long int'
real  - immutable ; implemented using the C/C++ data type 'double'
str   - *mutable* ; implemented as a dynamic C/C++ character array
---------
Compound:
---------
pair  - immutable ; implemented using C++ STL 'pair' class from <utility>
list  - *mutable* ; implemented using C++ STL sequence container 'list'
=====
*/

class dataType_real
{
private:
	// const becuase dataType_real is immutable
	const double val;

	// this function defines binary operations on real numbers
	static double applyMethod(const string &method, const dataType_real &obj, const dataType_real &arg)
	{
		if(method=="add")
			return obj.val + arg.val;
		else if(method=="sub")
			return obj.val - arg.val;
		else if(method=="mul")
			return obj.val * arg.val;
		else if(method=="div")
			return obj.val / arg.val;
		else if(method=="pow")
			return pow(obj.val, arg.val);
		else
			throw memberNotFoundException(method);
	}

	// this function defines single-argument/unary operations on real numbers
	static double applyMethod(const string &method, const dataType_real &obj)
	{
		if(method=="abs")
			return fabs(obj.val);
		else if(method=="floor")
			return floor(obj.val);
		else if(method=="ceil")
			return ceil(obj.val);
		else
			throw memberNotFoundException(method);
	}

public:
	/*
	The only way to set val is by calling the constructor.
	This means that once val is set, its value is permanent.
	*/
	dataType_real(const string &vs) : val(atof(vs.c_str())) {}
	dataType_real(const dataType_real &obj, const string &method) : val(applyMethod(method, obj)) {}
	dataType_real(const dataType_real &obj, const string &method, const dataType_real &arg) : val(applyMethod(method, obj, arg)) {}

	// Return string representation:
	string toString() const { return cons(val); }
};

/*

UserObjectClass
===============
UserObjectClass member function defintions follow.
typeID is use to denote the type of the data pointed to 
by void *value. typeID numbers for each primitive:

Basic:
------
null  - 11
byte  - 22
int   - 44
real  - 66
str   - 77

Compound:
---------
pair  - 88
list  - 99

*/

// Macros for each datatype...
#define DATATYPE_null 11
#define DATATYPE_byte 22
#define DATATYPE_int  44
#define DATATYPE_real 66
#define DATATYPE_str  77  
#define DATATYPE_pair 88
#define DATATYPE_list 99

// default constructor
UserObjectClass::UserObjectClass()
{
	typeID = DATATYPE_null;
	value = NULL;
}

// copy constructor
UserObjectClass::UserObjectClass(const UserObjectClass &copy)
{
	typeID = copy.typeID;
	value = new dataType_real(*((dataType_real *)(copy.value)));
}

// assignment operator
UserObjectClass & UserObjectClass::operator=(const UserObjectClass &rhs)
{
	// deleting old data before storing new data...
	this->~UserObjectClass();

	// now copying from rhs
	typeID = rhs.typeID;
	value = new dataType_real(*((dataType_real *)(rhs.value)));
	return *this;
}

// swap
void UserObjectClass::swap(UserObjectClass &x)
{
	// XOR swap 'typeID'
	typeID ^= x.typeID;
	x.typeID ^= typeID;
	typeID ^= x.typeID;

	// swap 'value'
	void *temp = value;
	value = x.value;
	x.value = temp;
}

// destructor
UserObjectClass::~UserObjectClass()
{
	if(value != NULL) {
		delete value;
		value = NULL;
		typeID = DATATYPE_null;
	}
}

///////////////////
// Core Functions:
///////////////////

// construct object with the result of the function call 'obj.method(arg)'
UserObjectClass::UserObjectClass(const string &method, const UserObjectClass &obj, const UserObjectClass &arg)
{
	typeID = DATATYPE_real;

	// (obj.typeID==DATATYPE_real)

	if(arg.typeID == DATATYPE_null) // use result of 'obj.method'
		value = new dataType_real( (obj.typeID==DATATYPE_real) ? *((dataType_real *)(obj.value)) : dataType_real(""), method);
	else
		value = new dataType_real( (obj.typeID==DATATYPE_real) ? *((dataType_real *)(obj.value)) : dataType_real(""), method, *((dataType_real *)(arg.value)));
}

// construct object from string
UserObjectClass::UserObjectClass(const string &content)
{
	typeID = DATATYPE_real;
	value = new dataType_real(content);
}

// convert object to string
string UserObjectClass::toString()
{
	if(typeID == DATATYPE_real)
	{
		dataType_real *current_value = (dataType_real *) value;
		return current_value->toString();
	}
	else
		return "(null)";
}

// Switching off datatype macros...
#undef DATATYPE_null
#undef DATATYPE_byte
#undef DATATYPE_int
#undef DATATYPE_real
#undef DATATYPE_str
#undef DATATYPE_pair
#undef DATATYPE_list
