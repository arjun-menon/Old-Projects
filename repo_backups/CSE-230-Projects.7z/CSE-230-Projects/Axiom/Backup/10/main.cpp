
#include <iostream>
#include <string>

int main()
{
	std::cout<<"\nAXIOM-REPL: "<<std::endl;

	// exec function prototype:
	std::string exec(const char *str);

	// to hold user input
	std::string input = "";

	while(true)
	{
		std::cout<<"\n> ";
		getline(std::cin, input);

		if(input=="quit")
			break;
		else
			std::cout<<exec(input.c_str());
	}

	return 0;
}
