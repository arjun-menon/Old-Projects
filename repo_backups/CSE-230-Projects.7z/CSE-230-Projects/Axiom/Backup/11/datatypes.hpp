
class UserObjectClass
{
private:
	char typeID;
	void *value;
public:
	UserObjectClass();
	UserObjectClass(const UserObjectClass &copy);
	UserObjectClass & operator=(const UserObjectClass &rhs);
	void swap(UserObjectClass &x);
	~UserObjectClass();

	UserObjectClass(const string &method, const UserObjectClass &obj, const UserObjectClass &arg);
	UserObjectClass(const string &content);
	string toString();
};

class memberNotFoundException : public genericException 
{
	public : memberNotFoundException(string name) : 
	genericException("Non-existant member \""+name+"\" invoked.", false) {}; 
};
