
#include <iostream>
#include "common.hpp"

class dataType
{
public:
	virtual int fetch_member(int k) = 0;
};

class dataType_num : public dataType
{
private:
	double num_val;

public:
	dataType_num(const double &k) : num_val(k) { cout<<"Con num...\n"; }
	dataType_num(const dataType_num &copy) : num_val(copy.num_val) { cout<<"Cpy DT num...\n"; }
	~dataType_num() { cout<<"Del DT num...\n"; }

	double get_num() { return num_val; }
	void set_num(double &k) { num_val = k; }
	virtual int fetch_member(int k) { return 100+k; }
};

class dataType_str : public dataType
{
private:
	string str_val;

public:
	dataType_str(const string &k) : str_val(k) { cout<<"Con DT str...\n"; }
	dataType_str(const dataType_str &copy) : str_val(copy.str_val) { cout<<"Cpy DT num...\n"; }
	~dataType_str() { cout<<"Del DT str...\n"; }

	string get_str() { return str_val; }
	void set_str(string &k) { str_val = k; }
	virtual int fetch_member(int k) { return 1000+k; }
};

#define DATATYPE_null 11
#define DATATYPE_num  22
#define DATATYPE_str  44

class UserObjkClass
{
private:
	char dataTypeID;
	dataType *data;

public:
	char whatType()
	{
		return dataTypeID;
	}
	dataType * get_data()
	{
		return data;
	}

	UserObjkClass()
	{
		cout<<"Con UO null...\n";
		dataTypeID = DATATYPE_null;
		data = NULL;
	}

	UserObjkClass(dataType_num &k_num)
	{
		cout<<"Con UO num...\n";
		dataTypeID = DATATYPE_num;
		data = new dataType_num(k_num);
	}

	UserObjkClass(dataType_str &k_str)
	{
		cout<<"Con UO str...\n";
		dataTypeID = DATATYPE_str;
		data = new dataType_str(k_str);
	}

	~UserObjkClass()
	{
		if(data != NULL) {
			cout<<"Del UO (valid)...\n";
			data = NULL;
			dataTypeID = DATATYPE_null;
		}
		else
			cout<<"Del UO (null)...\n";
	}

	virtual int fetch_member(int k)
	{
		if(data != NULL)
		{
			return data->fetch_member(k);
		}
		else
			return 0;
	}
};

UserObjkClass makeUserObjk_fromString(string &s)
{
	#define isNumeric(C) ( (C>='0') && (C<='9') )

	if(isNumeric( *(s.c_str()) ))
		return UserObjkClass(dataType_num(atof(s.c_str())));
	else if( *(s.c_str()) == '\"' )
		return UserObjkClass(dataType_str(s));
	else
		return UserObjkClass();
}

string displayUserObjk(UserObjkClass &obj)
{
	if(obj.whatType()==DATATYPE_num)
	{
		dataType_num *ptr = 0;
		if( ( ptr=dynamic_cast<dataType_num *>(obj.get_data()) )==0 )
			throw genericException("Dynamic cast failure.", true);
		else
			return cons(ptr->get_num());
	}
	else if(obj.whatType()==DATATYPE_str)
	{
		dataType_str *ptr = 0;
		if( ( ptr=dynamic_cast<dataType_str *>(obj.get_data()) )==0 )
			throw genericException("Dynamic cast failure.", true);
		else
			return cons(ptr->get_str());
	}
	else
		return "(null)";
}

bool isValidIdentifier(const char *str)
{
	// checks the syntactical validity
	// of a proposed identifier.

	if(*str>='0'&&*str<='9')
		return false;

	for(;*str!='\0';str++)
		if((*str<'A'||*str>'Z')
		&& (*str<'a'||*str>'z')
		&& (*str<'0'||*str>'9')
		&& (*str!='_'))
			return false;

	return true;
}
void hmmm()
{
	cout<<"\nPART 1\n\n";

	dataType_num a(5);
	cout<<a.get_num()<<endl;
	dataType_str b("brrr");
	cout<<b.get_str()<<endl<<endl;

	dataType *p1 = &a, *p2 = &b;
	cout<<p1->fetch_member(7)<<endl;
	cout<<p2->fetch_member(7)<<endl;

	cout<<"\nPART 2\n\n";

	UserObjkClass x;
	UserObjkClass y(a);
	UserObjkClass z(b);
	UserObjkClass w(dataType_num(456));

	cout<<x.fetch_member(3)<<endl;
	cout<<y.fetch_member(3)<<endl;
	cout<<z.fetch_member(3)<<endl;
	cout<<w.fetch_member(3)<<endl;

	cout<<"\nPART 3\n\n";

	UserObjkClass ms = makeUserObjk_fromString((string)("555"));
	cout<<endl<<displayUserObjk(ms)<<endl;
	cout<<endl<<displayUserObjk( makeUserObjk_fromString((string)("\"abc")) )<<endl;

	cout<<"\nPART 4\n\n";

	cout<<isValidIdentifier("blv4u");
	cout<<isValidIdentifier("sf234ij_saf234jk__s23");
	cout<<isValidIdentifier("___dfa34s_3234blvu");
	cout<<isValidIdentifier("23blvu");
	cout<<isValidIdentifier("543");
	cout<<isValidIdentifier("*&&^");

	cout<<"\nDESTRUCTION\n\n";
};
