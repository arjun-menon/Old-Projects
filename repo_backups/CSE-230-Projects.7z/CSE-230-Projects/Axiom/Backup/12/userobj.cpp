
#include <iostream>
#include "common.hpp"

class UserObjkClass; // prototype

class dataType
{
public:
	virtual UserObjkClass fetch_member(string name) = 0;
};

// prototypes:
class dataType_num;
class dataType_str;

class UserObjkClass
{
private:
	char dataTypeID;
	dataType *data;

public:
	char whatType();
	dataType * get_data();
	UserObjkClass();
	UserObjkClass(dataType_num &k_num);
	UserObjkClass(dataType_str &k_str);
	~UserObjkClass();
	UserObjkClass(const UserObjkClass &copyFrom);
	UserObjkClass & operator=(const UserObjkClass &rhs);
	UserObjkClass fetchMember(string name);

private:
	void copy(const UserObjkClass &obj);
	void clear();
};

/***********.
| Datatypes |
\***********/

// inc, dec, abs
class dataType_num : public dataType
{
private:
	double num_val;

public:
	dataType_num(const double &k) : num_val(k) { cout<<"Con num...\n"; }
	dataType_num(const dataType_num &copy) : num_val(copy.num_val) { cout<<"Cpy DT num...\n"; }
	~dataType_num() { cout<<"Del DT num...\n"; }

	double get_num() { return num_val; }
	void set_num(double &k) { num_val = k; }

	UserObjkClass fetch_member(string name)
	{
		ASSERT(isValidIdentifier(name));
		return UserObjkClass();
	}
};

class dataType_str : public dataType
{
private:
	string str_val;

public:
	dataType_str(const string &k) : str_val(k) { cout<<"Con DT str...\n"; }
	dataType_str(const dataType_str &copy) : str_val(copy.str_val) { cout<<"Cpy DT num...\n"; }
	~dataType_str() { cout<<"Del DT str...\n"; }

	string get_str() { return str_val; }
	void set_str(string &k) { str_val = k; }
	UserObjkClass fetch_member(string name)
	{
		ASSERT(isValidIdentifier(name));

		if(name=="len")
			return UserObjkClass(dataType_num(str_val.length()));
		else
			return UserObjkClass();
	}
};

/*****************.
| UserObjectClass |
\*****************/

#define DATATYPE_null 11
#define DATATYPE_num  22
#define DATATYPE_str  44

char UserObjkClass::whatType()
{
	return dataTypeID;
}
dataType * UserObjkClass::get_data()
{
	return data;
}

UserObjkClass::UserObjkClass()
{
	cout<<"Con UO null...\n";
	dataTypeID = DATATYPE_null;
	data = NULL;
}

UserObjkClass::UserObjkClass(dataType_num &k_num)
{
	cout<<"Con UO num...\n";
	dataTypeID = DATATYPE_num;
	data = new dataType_num(k_num);
}

UserObjkClass::UserObjkClass(dataType_str &k_str)
{
	cout<<"Con UO str...\n";
	dataTypeID = DATATYPE_str;
	data = new dataType_str(k_str);
}

UserObjkClass::~UserObjkClass()
{
	clear();
}

UserObjkClass::UserObjkClass(const UserObjkClass &copyFrom)
{
	copy(copyFrom);
}
UserObjkClass & UserObjkClass::operator=(const UserObjkClass &rhs)
{
	cout<<"ASG UO...\n";
	clear();
	copy(rhs);
	return *this;
}

UserObjkClass UserObjkClass::fetchMember(string name)
{
	if(data != NULL)
		return data->fetch_member(name);
	else
		return UserObjkClass();
}

void UserObjkClass::copy(const UserObjkClass &obj)
{
	cout<<"CPY UO...\n";
	dataTypeID = obj.dataTypeID;
	data = obj.data;
}

void UserObjkClass::clear()
{
	if(data != NULL)
	{
		cout<<"Del UO (valid)...\n";
		switch(dataTypeID)
		{
		case DATATYPE_num:
			{
				dataType_num *ptr = 0;
				ASSERT(( ptr=dynamic_cast<dataType_num *>(data) )!=0);
				delete ptr;
			}
			break;
		case DATATYPE_str:
			{
				dataType_str *ptr = 0;
				ASSERT(( ptr=dynamic_cast<dataType_str *>(data) )!=0);
				delete ptr;
			}
			break;
		default:
			throw fatalError("Badly constructed UserObject.");
		}
		dataTypeID = DATATYPE_null;
	}
	else {
		ASSERT(dataTypeID==DATATYPE_null);
		cout<<"Del UO (null)...\n";
	}
}

/******************************.
| UserObject Service Functions |
\******************************/

UserObjkClass makeUserObjk_fromString(const string &s)
{
	if(!s.empty())
	{
		#define isNumeric(C) ( (C>='0') && (C<='9') )

		if(isNumeric( *(s.c_str()) ))
			return UserObjkClass(dataType_num(atof(s.c_str())));

		#undef isNumeric

		else if(s.size()>=2)
		{
			if( (s.at(0)=='\"') && s.at(s.size()-1)=='\"' )
				return UserObjkClass(dataType_str(s.substr(1, s.size()-2)));
		}
	}
	return UserObjkClass();
}

string displayUserObjk(UserObjkClass &obj)
{
	if(obj.whatType()==DATATYPE_num)
	{
		dataType_num *ptr = 0;
		ASSERT(( ptr=dynamic_cast<dataType_num *>(obj.get_data()) )!=0);

		return cons(ptr->get_num());
	}
	else if(obj.whatType()==DATATYPE_str)
	{
		dataType_str *ptr = 0;
		ASSERT(( ptr=dynamic_cast<dataType_str *>(obj.get_data()) )!=0);

		return cons(ptr->get_str());
	}
	else
		return "(null)";
}

void hmmm()
{
	cout<<"\nPART 1\n\n";

	dataType_num a(5);
	dataType_str b("brrr");
	dataType *p1 = &a, *p2 = &b;

	cout<<a.get_num()<<" ---> "<<displayUserObjk(p1->fetch_member("inc"))<<endl;
	cout<<b.get_str()<<" ---> "<<displayUserObjk(p2->fetch_member("len"))<<endl;

	cout<<"\nPART 2\n\n";

	UserObjkClass x;
	UserObjkClass y(a);
	UserObjkClass z(b);
	UserObjkClass w(dataType_num(456));

	cout<<"\nPART 3\n\n";

	UserObjkClass ms = makeUserObjk_fromString((string)("555"));
	cout<<endl<<displayUserObjk(ms)<<endl;
	cout<<endl<<displayUserObjk( makeUserObjk_fromString((string)("\"\"")) )<<endl;

	cout<<"\nPART 4\n\n";

	UserObjkClass ii(dataType_num(999));
	UserObjkClass jj(dataType_str("pssst"));

	UserObjkClass iii = ii;
	UserObjkClass jjj;
	jjj = jj;

	cout<<endl;
	cout<<displayUserObjk(ii)<<" == "<<displayUserObjk(iii)<<endl;
	cout<<displayUserObjk(jj)<<" == "<<displayUserObjk(jjj)<<endl;

	cout<<"\nDESTRUCTION\n\n";
};
