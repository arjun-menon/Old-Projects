
#include "common.h"

/*****************.
| Datatype Number |
\*****************/

double convertUserObjk_toNumber(const UserObjkClass &obj)
{
	switch(obj.whatType())
	{
	case DATATYPE_num:
		{
			const dataType_num *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_num *>(obj.get_data()) )!=0);

			return ptr->get_num();
		}
		break;

	case DATATYPE_str:
		{
			const dataType_str *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_str *>(obj.get_data()) )!=0);

			return atof((ptr->get_str()).c_str());
		}
		break;

	case DATATYPE_null:
		return 0;

	default:
		throw userError("Type mismatch");
	}
}

UserObjkClass dataType_num::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="post_inc") {
		dataType_num init_value(num_val);
		num_val++;
		return UserObjkClass(init_value);
	}
	else if(name=="add") {
		cout<<"BOOM!!!\n";
		return UserObjkClass(dataType_num("add", num_val));
	}
	else
		return UserObjkClass();
}

UserObjkClass dataType_num::call_function(const UserObjkClass &arg)
{
	if(functional=="add")
	{
		return UserObjkClass(dataType_num( num_val + convertUserObjk_toNumber(arg) ));
	}
	else
		throw userError("You cannot perform a function call on a number.");
}

/*****************.
| Datatype String |
\*****************/

UserObjkClass dataType_str::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="len")
		return UserObjkClass(dataType_num(str_val.length()));
	else
		return UserObjkClass();
}

UserObjkClass dataType_str::call_function(const UserObjkClass &arg)
{
	throw userError("You cannot perform a function call on a string.");
}
