
#include "common.h"

/*****************.
| UserObjectClass |
\*****************/

char UserObjkClass::whatType() const
{
	return dataTypeID;
}
const dataType * UserObjkClass::get_data() const
{
	return data;
}

UserObjkClass::UserObjkClass()
{
	cout<<"Con UO null...\n";
	dataTypeID = DATATYPE_null;
	data = NULL;
}

UserObjkClass::UserObjkClass(dataType_num &k_num)
{
	cout<<"Con UO num...\n";
	dataTypeID = DATATYPE_num;
	data = new dataType_num(k_num);
}

UserObjkClass::UserObjkClass(dataType_str &k_str)
{
	cout<<"Con UO str...\n";
	dataTypeID = DATATYPE_str;
	data = new dataType_str(k_str);
}

UserObjkClass::UserObjkClass(const UserObjkClass &copyFrom)
{
	copy(copyFrom);
}

UserObjkClass & UserObjkClass::operator=(const UserObjkClass &rhs)
{
	cout<<"ASG UO...\n";
	clear();
	copy(rhs);
	return *this;
}

UserObjkClass::~UserObjkClass()
{
	clear();
}

UserObjkClass UserObjkClass::fetchMember(const string &name) const
{
	if(data != NULL)
		return data->fetch_member(name);
	else
		return UserObjkClass();
}

UserObjkClass UserObjkClass::callFunction(const UserObjkClass &arg) const
{
	if(data != NULL)
		return data->call_function(arg);
	else
		return UserObjkClass();
}

void UserObjkClass::copy(const UserObjkClass &obj)
{
	cout<<"CPY UO...\n";
	if(obj.data != NULL)
	{
		switch(obj.dataTypeID)
		{
		case DATATYPE_num:
			{
				dataType_num *num_dt_ptr = 0;
				ASSERT(( num_dt_ptr=dynamic_cast<dataType_num *>(obj.data) )!=0);
				data = new dataType_num(*num_dt_ptr);
			}
			break;
		case DATATYPE_str:
			{
				dataType_str *str_dt_ptr = 0;
				ASSERT(( str_dt_ptr=dynamic_cast<dataType_str *>(obj.data) )!=0);
				data = new dataType_str(*str_dt_ptr);
			}
			break;
		default:
			throw badUserObjkError();
		}
	}
	else
		data = NULL;

	dataTypeID = obj.dataTypeID;
}

void UserObjkClass::clear()
{
	if(data != NULL)
	{
		cout<<"Del UO (valid)...\n";
		switch(dataTypeID)
		{
		case DATATYPE_num:
			{
				dataType_num *num_dt_ptr = 0;
				ASSERT(( num_dt_ptr=dynamic_cast<dataType_num *>(data) )!=0);
				delete num_dt_ptr;
			}
			break;
		case DATATYPE_str:
			{
				dataType_str *str_dt_ptr = 0;
				ASSERT(( str_dt_ptr=dynamic_cast<dataType_str *>(data) )!=0);
				delete str_dt_ptr;
			}
			break;
		default:
			throw badUserObjkError();
		}
		dataTypeID = DATATYPE_null;
	}
	else {
		ASSERT(dataTypeID==DATATYPE_null);
		cout<<"Del UO (null)...\n";
	}
}

/******************************.
| UserObject Service Functions |
\******************************/

UserObjkClass makeUserObjk_fromString(const string &s)
{
	if(!s.empty())
	{
		#define isNumeric(C) ( (C>='0') && (C<='9') )

		if(isNumeric( *(s.c_str()) ))
			return UserObjkClass(dataType_num(atof(s.c_str())));

		#undef isNumeric

		else if(s.size()>=2)
		{
			if( (s.at(0)=='\"') && s.at(s.size()-1)=='\"' )
				return UserObjkClass(dataType_str(s.substr(1, s.size()-2)));
		}
	}
	return UserObjkClass();
}

string displayUserObjk(UserObjkClass &obj)
{
	switch(obj.whatType())
	{
	case DATATYPE_num:
		{
			const dataType_num *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_num *>(obj.get_data()) )!=0);

			return cons(ptr->get_num());
		}
		break;

	case DATATYPE_str:
		{
			const dataType_str *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_str *>(obj.get_data()) )!=0);

			return cons(ptr->get_str());
		}
		break;

	case DATATYPE_null:
		return "(null)";

	default:
		throw badUserObjkError();
	}
}

void hmmm()
{
	cout<<"\nPART 1\n\n";

	UserObjkClass a(dataType_num(33));
	UserObjkClass a_add(a.fetchMember("add"));

	UserObjkClass x(dataType_num(21));
	UserObjkClass y(dataType_str("50"));

	cout<<displayUserObjk(a)<<endl;
	cout<<displayUserObjk(x)<<endl;
	cout<<displayUserObjk(y)<<endl;
	cout<<displayUserObjk(a_add.callFunction(x))<<endl;
	cout<<displayUserObjk(a_add.callFunction(y))<<endl;

	cout<<"\nDESTRUCTION\n\n";
};
