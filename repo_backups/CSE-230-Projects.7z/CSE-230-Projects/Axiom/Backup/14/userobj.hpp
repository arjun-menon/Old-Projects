
class UserObjkClass
{
private:
	char dataTypeID;
	dataType *data;

public:
	char whatType() const;
	const dataType * get_data() const;

	UserObjkClass();
	UserObjkClass(dataType_num &k_num);
	UserObjkClass(dataType_str &k_str);
	UserObjkClass(const UserObjkClass &copyFrom);
	UserObjkClass & operator=(const UserObjkClass &rhs);
	~UserObjkClass();

	UserObjkClass fetchMember(const string &name) const;
	UserObjkClass callFunction(const UserObjkClass &arg) const;

private:
	void copy(const UserObjkClass &obj);
	void clear();
};

class badUserObjkError : public fatalError
{
	public: badUserObjkError() : 
	fatalError("Badly constructed UserObject.") {}
};
