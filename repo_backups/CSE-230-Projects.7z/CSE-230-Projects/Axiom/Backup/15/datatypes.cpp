
#include "common.h"

/*****************.
| Datatype Number |
\*****************/

double convertUserObject_toNumber(const UserObjectClass &obj)
{
	switch(obj.whatType())
	{
	case DATATYPE_num:
		{
			const dataType_num *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_num *>(obj.get_data()) )!=0);

			return ptr->get_num();
		}
		break;

	case DATATYPE_str:
		{
			const dataType_str *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_str *>(obj.get_data()) )!=0);

			return atof((ptr->get_str()).c_str());
		}
		break;

	case DATATYPE_null:
		return 0;

	default:
		throw userError("Type mismatch");
	}
}

UserObjectClass dataType_num::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="post_inc") {
		dataType_num init_value(num_val);
		num_val++;
		return UserObjectClass(init_value);
	}
	else if(name=="neg")
		return UserObjectClass(dataType_num(-(num_val)));
	else if(name=="abs")
		return UserObjectClass(dataType_num(fabs(num_val)));

	#define IF_RFN(S) if(name==S) return UserObjectClass(dataType_num(S, num_val))

	// functional-type memebers:
	else IF_RFN("add");
	else IF_RFN("sub");
	else IF_RFN("mul");
	else IF_RFN("div");
	else IF_RFN("mod");
	else IF_RFN("pow");

	#undef IF_RFN

	else
		throw memberNotFoundException(name, "Number");
}

UserObjectClass dataType_num::call_function(const UserObjectClass &arg)
{
	if(functional.empty())
		throw userError("You cannot perform a function call on a number.");
	else
	{
		if(functional=="add")
			return UserObjectClass(dataType_num( num_val + convertUserObject_toNumber(arg) ));
		else if(functional=="sub")
			return UserObjectClass(dataType_num( num_val - convertUserObject_toNumber(arg) ));
		else if(functional=="mul")
			return UserObjectClass(dataType_num( num_val * convertUserObject_toNumber(arg) ));
		else if(functional=="div")
			return UserObjectClass(dataType_num( num_val / convertUserObject_toNumber(arg) ));
		else if(functional=="mod")
			return UserObjectClass(dataType_num( fmod(num_val, convertUserObject_toNumber(arg)) ));
		else if(functional=="pow")
			return UserObjectClass(dataType_num( pow(num_val, convertUserObject_toNumber(arg)) ));
		else
			throw functionNotFoundException(functional);
	}
}

/*****************.
| Datatype String |
\*****************/

UserObjectClass dataType_str::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="len")
		return UserObjectClass(dataType_num(str_val.length()));
	else
		throw memberNotFoundException(name, "String");
}

UserObjectClass dataType_str::call_function(const UserObjectClass &arg)
{
	throw userError("You cannot perform a function call on a string.");
}
