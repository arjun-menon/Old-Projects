
class UserObjectClass;  // prototype

class dataType
{
public:
	virtual UserObjectClass fetch_member(const string &name) = 0;
	virtual UserObjectClass call_function(const UserObjectClass &arg) = 0;
};

class dataType_num : public dataType
{
private:
	double num_val;
	string functional;

public:
	dataType_num(const double &k) : num_val(k), functional("") { cout<<"Con num...\n"; }
	dataType_num(const dataType_num &copy) : num_val(copy.num_val), functional(copy.functional) { cout<<"Cpy DT num...\n"; }
	dataType_num(const string &fn_call, const double &k) : functional(fn_call), num_val(k) {}
	~dataType_num() { cout<<"Del DT num...\n"; }

	double get_num() const { return num_val; }
	void set_num(double &k) { num_val = k; }

	UserObjectClass fetch_member(const string &name);
	UserObjectClass call_function(const UserObjectClass &arg);
};

class dataType_str : public dataType
{
private:
	string str_val;

public:
	dataType_str(const string &k) : str_val(k) { cout<<"Con DT str...\n"; }
	dataType_str(const dataType_str &copy) : str_val(copy.str_val) { cout<<"Cpy DT num...\n"; }
	~dataType_str() { cout<<"Del DT str...\n"; }

	string get_str() const { return str_val; }
	void set_str(const string &k) { str_val = k; }

	UserObjectClass fetch_member(const string &name);
	UserObjectClass call_function(const UserObjectClass &arg);
};

#define DATATYPE_null 11
#define DATATYPE_num  22
#define DATATYPE_str  44

class memberNotFoundException : public userError
{
	public : memberNotFoundException(string method_name, string obj_name="Object") : 
	userError(obj_name + " does not have a member called \""+method_name+"\".") {}; 
};

class functionNotFoundException : public fatalError
{
	public : functionNotFoundException(string name) : 
	fatalError("Non-existant function \""+name+"\" invoked.") {};
};
