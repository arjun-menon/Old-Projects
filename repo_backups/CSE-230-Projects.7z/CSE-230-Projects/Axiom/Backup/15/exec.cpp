
#include "common.h"

// binary operators
map<string, float> bops;

void init_bops()
{
	bops["+"] = 1;
	bops["-"] = 1;
	bops["*"] = 2;
	bops["/"] = 2;
	bops["%"] = 2;
	bops["**"] = 3;
	bops["++"] = 3;
	bops["."] = 5;
}

frag_chain::iterator findBinaryOperator(frag_chain &frags)
{
	frag_chain::iterator pos = frags.end();
	map<string, float>::const_iterator bop = bops.begin();
	// check if bops is empty
	if(bop==bops.end())
		return pos;

	float max;
	// calculate max, whose value is greater than that of 
	// the binary operator with the greatest mapped value.
	for(max = (bop++)->second; bop!=bops.end(); bop++)
		if(bop->second > max)
			max = bop->second;
	max++;

	// Now find the binary operator with *lowest* precedence:
	for(frag_chain::iterator i = frags.begin(); i!=frags.end(); i++) {
		if(i->size() == 1) { // bop must be a unit fragment
			if((bop = bops.find(i->front()))!=bops.end()) {
				if(bop->second < max) {
					pos = i;
					max = bop->second;
				}
			}
		}
	}

	return pos;
}

UserObjectClass eval(frag_chain frags); // prototype - used for recursion

UserObjectClass applyBOP(string bop, frag_chain lhs, frag_chain rhs)
{
	if(bop == ".")
	{
		if(!rhs.empty())
		{
			if(!rhs.front().empty())
			{
				string method_name = rhs.front().front();

				if(isValidIdentifier(method_name))
					return eval(lhs).fetchMember(method_name);
				else
					throw userError("Invalid method. Method names must follow identifier syntax.");
			}
			else
				throw fragError();
		} else
			throw userError("Method name missing.");
	}
	else {
		if(bop=="++")
			return eval(lhs).fetchMember("post_inc");

		// always do lhs first, then rhs.
		#define RFN(S) return eval(lhs).fetchMember(S).callFunction(eval(rhs))

		else if(bop=="+")   RFN("add");
		else if(bop=="-")   RFN("sub");
		else if(bop=="*")   RFN("mul");
		else if(bop=="/")   RFN("div");
		else if(bop=="%")   RFN("mod");
		else if(bop=="**")  RFN("pow");

		#undef RFN

		else
			return UserObjectClass();
	}
}

UserObjectClass eval(frag_chain frags)
{
	if(frags.size() < 1)
	{
		// frags is empty, so return null UserObj; this
		// happens either when there is a blank expr or ()
		return UserObjectClass(); // *** Base Case ***
	}
	else if(frags.size() == 1)
	{
		tok_chain toks = frags.front();

		if(toks.size() > 1)
		{
			// strip parentheses
			ASSERT(toks.front()=="(");
			ASSERT(toks.back()==")");
			toks.pop_front();
			toks.pop_back();

			// *** Recursive Call ***
			return eval(Fragmentize(toks));
		}
		else if(toks.size() == 1)
		{
			// we have reached a unit fragment *** Base Case ***
			//return UserObjectClass(toks.front());
			return makeUserObject_fromString(toks.front());
		}
		else
		{
			// empty token chain - fragmentation fault
			throw fragError();
		}
	}
	else // if(frags.size() > 1)
	{
		frag_chain::iterator pos;

		// search for binary operator
		if((pos = findBinaryOperator(frags)) != frags.end())
		{
			// found a binary operator
			frag_chain lhs_frags, rhs_frags;

			lhs_frags.splice(lhs_frags.begin(), frags, frags.begin(), pos);
			pos = frags.begin();
			rhs_frags.splice(rhs_frags.begin(), frags, ++pos, frags.end());

			// now applying binary operation - *** Expect Recursion ***
			return applyBOP(*(frags.begin()->begin()), lhs_frags, rhs_frags);
		}
		else
		{
			// perform function call
			throw userError("Not implemented.\n"+display_frags(frags));
		}
	}
}

string exec(const char *str)
{
	try
	{
		//void hmmm();
		//hmmm();
		//return "";
		init_bops();
		return displayUserObject(eval(Fragmentize(Tokenize(str))));
	}
	catch(exception &e) {
		return e.what();
	}
	catch(...) {
		return fatalError("Unhandled Exception.").what();
	}
}
