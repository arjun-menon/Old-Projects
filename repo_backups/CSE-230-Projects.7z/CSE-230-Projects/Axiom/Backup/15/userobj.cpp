
#include "common.h"

/*****************.
| UserObjectClass |
\*****************/

char UserObjectClass::whatType() const
{
	return dataTypeID;
}
const dataType * UserObjectClass::get_data() const
{
	return data;
}

UserObjectClass::UserObjectClass()
{
	cout<<"Con UO null...\n";
	dataTypeID = DATATYPE_null;
	data = NULL;
}

UserObjectClass::UserObjectClass(dataType_num &k_num)
{
	cout<<"Con UO num...\n";
	dataTypeID = DATATYPE_num;
	data = new dataType_num(k_num);
}

UserObjectClass::UserObjectClass(dataType_str &k_str)
{
	cout<<"Con UO str...\n";
	dataTypeID = DATATYPE_str;
	data = new dataType_str(k_str);
}

UserObjectClass::UserObjectClass(const UserObjectClass &copyFrom)
{
	copy(copyFrom);
}

UserObjectClass & UserObjectClass::operator=(const UserObjectClass &rhs)
{
	cout<<"ASG UO...\n";
	clear();
	copy(rhs);
	return *this;
}

UserObjectClass::~UserObjectClass()
{
	clear();
}

UserObjectClass UserObjectClass::fetchMember(const string &name) const
{
	if(data != NULL)
		return data->fetch_member(name);
	else
		return UserObjectClass();
}

UserObjectClass UserObjectClass::callFunction(const UserObjectClass &arg) const
{
	if(data != NULL)
		return data->call_function(arg);
	else
		return UserObjectClass();
}

void UserObjectClass::copy(const UserObjectClass &obj)
{
	cout<<"CPY UO...\n";
	if(obj.data != NULL)
	{
		switch(obj.dataTypeID)
		{
		case DATATYPE_num:
			{
				dataType_num *num_dt_ptr = 0;
				ASSERT(( num_dt_ptr=dynamic_cast<dataType_num *>(obj.data) )!=0);
				data = new dataType_num(*num_dt_ptr);
			}
			break;
		case DATATYPE_str:
			{
				dataType_str *str_dt_ptr = 0;
				ASSERT(( str_dt_ptr=dynamic_cast<dataType_str *>(obj.data) )!=0);
				data = new dataType_str(*str_dt_ptr);
			}
			break;
		default:
			throw badUserObjectError();
		}
	}
	else
		data = NULL;

	dataTypeID = obj.dataTypeID;
}

void UserObjectClass::clear()
{
	if(data != NULL)
	{
		cout<<"Del UO (valid)...\n";
		switch(dataTypeID)
		{
		case DATATYPE_num:
			{
				dataType_num *num_dt_ptr = 0;
				ASSERT(( num_dt_ptr=dynamic_cast<dataType_num *>(data) )!=0);
				delete num_dt_ptr;
			}
			break;
		case DATATYPE_str:
			{
				dataType_str *str_dt_ptr = 0;
				ASSERT(( str_dt_ptr=dynamic_cast<dataType_str *>(data) )!=0);
				delete str_dt_ptr;
			}
			break;
		default:
			throw badUserObjectError();
		}
		dataTypeID = DATATYPE_null;
	}
	else {
		ASSERT(dataTypeID==DATATYPE_null);
		cout<<"Del UO (null)...\n";
	}
}

/******************************.
| UserObject Service Functions |
\******************************/

UserObjectClass makeUserObject_fromString(const string &s)
{
	if(!s.empty())
	{
		#define isNumeric(C) ( (C>='0') && (C<='9') )

		if(isNumeric( *(s.c_str()) ))
			return UserObjectClass(dataType_num(atof(s.c_str())));

		#undef isNumeric

		else if(s.size()>=2)
		{
			if( (s.at(0)=='\"') && s.at(s.size()-1)=='\"' ) {
				cout<<s.substr(1, s.size()-2)<<endl;
				return UserObjectClass(dataType_str(s.substr(1, s.size()-2)));
			}
		}
	}
	return UserObjectClass();
}

string displayUserObject(UserObjectClass &obj)
{
	switch(obj.whatType())
	{
	case DATATYPE_num:
		{
			const dataType_num *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_num *>(obj.get_data()) )!=0);

			return cons(ptr->get_num());
		}
		break;

	case DATATYPE_str:
		{
			const dataType_str *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_str *>(obj.get_data()) )!=0);

			return cons(ptr->get_str());
		}
		break;

	case DATATYPE_null:
		return "(null)";

	default:
		throw badUserObjectError();
	}
}

void hmmm()
{
	cout<<"\nPART 1\n\n";



	cout<<"\nDESTRUCTION\n\n";
};
