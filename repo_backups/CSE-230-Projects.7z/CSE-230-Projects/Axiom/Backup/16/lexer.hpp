
// Typedefs
typedef deque<string> tok_chain; // NOTE !!! tok_chain = fragment
typedef list<tok_chain> frag_chain;

// Function prototypes
tok_chain Tokenize(const char *sp);
frag_chain Fragmentize(deque<string> &toks);
void trim(string &str, const string to_remove = " \t");
string display_toks(const tok_chain &);
string display_frags(const frag_chain &);
bool isValidIdentifier(string s);

class fragError : public fatalError
{
	public: fragError() : 
	fatalError("Fragmentation fault") {}
};

// Template to construct a string consisting of generic x
template <typename T> string cons(T x)
{
	stringstream s;
	s << x;
	return s.str();
}
