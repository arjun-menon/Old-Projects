
#include "common.h"

/***************.
| Datatype Null |
\***************/

// Trivial Functions:
// ------------------

dataType_null::dataType_null() : functional("") {}

dataType_null::dataType_null(const dataType_null &copy) : functional(copy.functional) {}

dataType_null::dataType_null(const string &fn_name) : functional(fn_name) {}

// Important Fucntions:
// ====================

UserObjectClass dataType_null::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="num")
		return UserObjectClass(dataType_num(0));
	if(name=="str")
		return UserObjectClass(dataType_str(""));

	else if(name=="sub")
		return UserObjectClass(dataType_null("sub"));

	else
		throw memberNotFoundException(name, "Null");
}

UserObjectClass dataType_null::call_function(const UserObjectClass &arg)
{
	if(functional.empty())
		throw userError("You cannot perform a function call on a number.");
	else
	{
		if(functional=="sub")
			return arg.fetchMember("neg");
		else
			throw functionNotFoundException(functional);
	}
}

/*****************.
| Datatype Number |
\*****************/

// Trivial Functions:
// ------------------

dataType_num::dataType_num(const double &k) : num_val(k), functional("") { cout<<"Con num...\n"; }

dataType_num::dataType_num(const dataType_num &copy) : num_val(copy.num_val), functional(copy.functional) 
{ cout<<"Cpy DT num...\n"; }

dataType_num::dataType_num(const string &fn_name, const double &k) : functional(fn_name), num_val(k) {}

dataType_num::~dataType_num() { cout<<"Del DT num...\n"; }

double dataType_num::get_num() const { return num_val; }

// Important Fucntions:
// ====================

UserObjectClass dataType_num::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="inc") {
		dataType_num init_value(num_val);
		num_val++;
		return UserObjectClass(init_value);
	}
	else if(name=="neg")
		return UserObjectClass(dataType_num(-(num_val)));
	else if(name=="abs")
		return UserObjectClass(dataType_num(fabs(num_val)));

	#define IF_RFN(S) if(name==S) return UserObjectClass(dataType_num(S, num_val))

	// functional-type memebers:
	else IF_RFN("add");
	else IF_RFN("sub");
	else IF_RFN("mul");
	else IF_RFN("div");
	else IF_RFN("mod");
	else IF_RFN("pow");

	#undef IF_RFN

	else
		throw memberNotFoundException(name, "Number");
}

UserObjectClass dataType_num::call_function(const UserObjectClass &arg)
{
	if(functional.empty())
		throw userError("You cannot perform a function call on a number.");
	else
	{
		if(functional=="add")
			return UserObjectClass(dataType_num( num_val + convertUserObject_toNumber(arg) ));
		else if(functional=="sub")
			return UserObjectClass(dataType_num( num_val - convertUserObject_toNumber(arg) ));
		else if(functional=="mul")
			return UserObjectClass(dataType_num( num_val * convertUserObject_toNumber(arg) ));
		else if(functional=="div")
			return UserObjectClass(dataType_num( num_val / convertUserObject_toNumber(arg) ));
		else if(functional=="mod")
			return UserObjectClass(dataType_num( fmod(num_val, convertUserObject_toNumber(arg)) ));
		else if(functional=="pow")
			return UserObjectClass(dataType_num( pow(num_val, convertUserObject_toNumber(arg)) ));
		else
			throw functionNotFoundException(functional);
	}
}

double dataType_num::convertUserObject_toNumber(const UserObjectClass &obj)
{
	switch(obj.whatType())
	{
	case DATATYPE_num:
		{
			const dataType_num *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_num *>(obj.get_data()) )!=0);

			return ptr->get_num();
		}
		break;

	case DATATYPE_str:
		{
			const dataType_str *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_str *>(obj.get_data()) )!=0);

			return atof((ptr->get_str()).c_str());
		}
		break;

	case DATATYPE_null:
		return 0;

	default:
		throw userError("Type mismatch");
	}
}

/*****************.
| Datatype String |
\*****************/

// Trivial Functions:
// ------------------

dataType_str::dataType_str(const string &k) : str_val(k) { cout<<"Con DT str...\n"; }

dataType_str::dataType_str(const dataType_str &copy) : str_val(copy.str_val) { cout<<"Cpy DT num...\n"; }

dataType_str::~dataType_str() { cout<<"Del DT str...\n"; }

string dataType_str::get_str() const { return str_val; }

// Important Fucntions:
// ====================

UserObjectClass dataType_str::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="len")
		return UserObjectClass(dataType_num(str_val.length()));
	else
		throw memberNotFoundException(name, "String");
}

UserObjectClass dataType_str::call_function(const UserObjectClass &arg)
{
	throw userError("You cannot perform a function call on a string.");
}
