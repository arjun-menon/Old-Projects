
class UserObjectClass
{
private:
	char dataTypeID;
	dataType *data;

public:
	char whatType() const;
	const dataType * get_data() const;

	UserObjectClass(dataType_null &k_null);
	UserObjectClass(dataType_num &k_num);
	UserObjectClass(dataType_str &k_str);
	UserObjectClass(dataType_list &k_list);

	UserObjectClass(const UserObjectClass &copyFrom);
	UserObjectClass & operator=(const UserObjectClass &rhs);
	~UserObjectClass();

	UserObjectClass fetchMember(const string &name) const;
	UserObjectClass callFunction(const UserObjectClass &arg) const;
	string toString();

private:
	void copy(const UserObjectClass &obj);
	void clear();
};

class badUserObjectError : public fatalError
{
	public: badUserObjectError() : 
	fatalError("Badly constructed UserObject.") {}
};

UserObjectClass makeUserObject_fromString(const string &s);
