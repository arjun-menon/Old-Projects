/*
 *     CSE 230 HW 5
 *
 *  Written by Arjun G. Menon
 *
 *             arjungmenon@gmail.com
 *         www.arjungmenon.com
 *
 */

// Classes
class userError : public exception
{
	// User Errors are due to the user's fault. 
private:
	const string error_description;
public:
	virtual const char* what() const throw() { return error_description.c_str(); }
	userError(string err) : error_description((string)("Error: ")+err) {}
};

class fatalError : public exception
{
	// Fatal Errors are due to the programmer's fault.
private:
	const string error_description;
public:
	virtual const char* what() const throw() { return error_description.c_str(); }
	fatalError(string err) : error_description((string)("Fatal Error: ")+err) {}
};

// Macros
#define UI unsigned int
#define UC unsigned char
#define ASSERT(X) if(!(X)) throw fatalError\
((string)("Assertion failure ( ")+(string)(#X)+(string)(" )"))
