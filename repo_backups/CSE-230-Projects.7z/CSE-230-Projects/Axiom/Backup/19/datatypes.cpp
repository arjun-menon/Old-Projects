/*
 *     CSE 230 HW 5
 *
 *  Written by Arjun G. Menon
 *
 *             arjungmenon@gmail.com
 *         www.arjungmenon.com
 *
 */

#include "common.h"

/***************.
| Datatype Null |
\***************/

// Trivial Functions:
// ------------------

dataType_null::dataType_null() : functional("")
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Constructing DataType null ...\n";
	#endif
}

dataType_null::dataType_null(const dataType_null &copy) : functional(copy.functional)
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Copying DataType null ...\n";
	#endif
}

dataType_null::dataType_null(const string &fn_name) : functional(fn_name)
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Constructing DataType *function* null ...\n";
	#endif
}

dataType_null::~dataType_null()
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Destroying DataType null ...\n";
	#endif
}

string dataType_null::string_repr()
{ return "(null)"; }

// Important Fucntions:
// ====================

UserObjectClass dataType_null::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="num")
		return UserObjectClass(dataType_num(0));
	if(name=="str")
		return UserObjectClass(dataType_str(""));

	else if(name=="sub")
		return UserObjectClass(dataType_null("sub"));

	else
		return UserObjectClass(dataType_null(name));
		//throw memberNotFoundException(name, "Null");
}

UserObjectClass dataType_null::call_function(const UserObjectClass &arg)
{
	if(functional.empty())
		throw userError("You cannot perform a function call on null.");
	else
	{
		if(functional=="sub")
			return arg.fetchMember("neg");
		else if(arg.whatType()!=DATATYPE_null)
			return arg.fetchMember(functional).callFunction(dataType_null());
		else
			throw functionNotFoundException(functional);
	}
}

/*****************.
| Datatype Number |
\*****************/

// Trivial Functions:
// ------------------

dataType_num::dataType_num(const double &k) : num_val(k), functional("")
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Constructing DataType num ...\n";
	#endif
}

dataType_num::dataType_num(const dataType_num &copy) : num_val(copy.num_val), functional(copy.functional) 
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Copying DataType num ...\n";
	#endif
}

dataType_num::dataType_num(const string &fn_name, const double &k) : functional(fn_name), num_val(k)
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Constructing DataType *function* num ...\n";
	#endif
}

dataType_num::~dataType_num()
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Destroying DataType num ...\n";
	#endif
}

double dataType_num::get_num() const
{ return num_val; }

string dataType_num::string_repr()
{ return cons(num_val); }

// Important Fucntions:
// ====================

UserObjectClass dataType_num::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="inc") {
		dataType_num init_value(num_val);
		num_val++;
		return UserObjectClass(init_value);
	}
	else if(name=="neg")
		return UserObjectClass(dataType_num(-(num_val)));
	else if(name=="abs")
		return UserObjectClass(dataType_num(fabs(num_val)));

	#define IF_RFN(S) if(name==S) return UserObjectClass(dataType_num(S, num_val))

	// functional-type memebers:
	else IF_RFN("add");
	else IF_RFN("sub");
	else IF_RFN("mul");
	else IF_RFN("div");
	else IF_RFN("mod");
	else IF_RFN("pow");

	#undef IF_RFN

	else
		throw memberNotFoundException(name, "Number");
}

UserObjectClass dataType_num::call_function(const UserObjectClass &arg)
{
	if(functional.empty())
		throw userError("You cannot perform a function call on a number.");
	else
	{
		if(functional=="add")
			return UserObjectClass(dataType_num( num_val + convertUserObject_toNumber(arg) ));
		else if(functional=="sub")
			return UserObjectClass(dataType_num( num_val - convertUserObject_toNumber(arg) ));
		else if(functional=="mul")
			return UserObjectClass(dataType_num( num_val * convertUserObject_toNumber(arg) ));
		else if(functional=="div")
			return UserObjectClass(dataType_num( num_val / convertUserObject_toNumber(arg) ));
		else if(functional=="mod")
			return UserObjectClass(dataType_num( fmod(num_val, convertUserObject_toNumber(arg)) ));
		else if(functional=="pow")
			return UserObjectClass(dataType_num( pow(num_val, convertUserObject_toNumber(arg)) ));
		else
			throw functionNotFoundException(functional);
	}
}

double dataType_num::convertUserObject_toNumber(const UserObjectClass &obj)
{
	switch(obj.whatType())
	{
	case DATATYPE_num:
		{
			const dataType_num *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_num *>(obj.get_data()) )!=0);

			return ptr->get_num();
		}
		break;

	case DATATYPE_str:
		{
			const dataType_str *ptr = 0;
			ASSERT(( ptr=dynamic_cast<const dataType_str *>(obj.get_data()) )!=0);

			return atof((ptr->get_str()).c_str());
		}
		break;

	case DATATYPE_null:
		return 0;

	default:
		throw userError("Type mismatch");
	}
}

/*****************.
| Datatype String |
\*****************/

// Trivial Functions:
// ------------------

dataType_str::dataType_str(const string &k) : str_val(k)
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Constructing DataType str ...\n";
	#endif
}

dataType_str::dataType_str(const dataType_str &copy) : str_val(copy.str_val)
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Copying DataType str ...\n";
	#endif
}

dataType_str::~dataType_str()
{
	#ifdef SHOW_DEBUG_MESSAGES
	cout<<"Destroying DataType str ...\n";
	#endif
}

string dataType_str::get_str() const
{ return str_val; }

string dataType_str::string_repr()
{ return str_val; }

// Important Fucntions:
// ====================

UserObjectClass dataType_str::fetch_member(const string &name)
{
	ASSERT(isValidIdentifier(name));

	if(name=="len")
		return UserObjectClass(dataType_num(str_val.length()));
	else
		throw memberNotFoundException(name, "String");
}

UserObjectClass dataType_str::call_function(const UserObjectClass &arg)
{
	throw userError("You cannot perform a function call on a string.");
}

/***************.
| Datatype Pair |
\***************/

// Trivial Functions:
// ------------------

dataType_pair::dataType_pair(const UserObjectClass &a, const UserObjectClass &b) : first(a), second(b)
{}

string dataType_pair::string_repr()
{
	return "( " + first.toString() + " => " + second.toString() + " )";
}

// Important Fucntions:
// ====================

UserObjectClass dataType_pair::fetch_member(const string &name)
{
	throw("The pair object has no members.");
}

UserObjectClass dataType_pair::call_function(const UserObjectClass &arg)
{
	throw("The pair cannot be called as a function");
}

/***************.
| Datatype List |
\***************/

// Trivial Functions:
// ------------------

string dataType_list::string_repr()
{
	string repr = "(";
	bool comma = false;

	for(list<UserObjectClass>::const_iterator i = mylist.begin(); i != mylist.end(); i++)
	{
		if(comma)
			repr += ", ";
		UserObjectClass k = *i;
		repr += k.toString();
		comma = true;
	}

	return repr + ")";
}

// Important Fucntions:
// ====================

UserObjectClass dataType_list::fetch_member(const string &name)
{
	throw("This list object has no members.");
}

UserObjectClass dataType_list::call_function(const UserObjectClass &arg)
{
	throw("This list cannot be called as a function");
}

void dataType_list::push_back(const UserObjectClass &obj)
{
	mylist.push_back(obj);
}
