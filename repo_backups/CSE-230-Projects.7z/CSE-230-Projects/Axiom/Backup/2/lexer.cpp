
#include "common.h"

frag_chain Fragmentize(tok_chain &toks)
{
	frag_chain frags;

	while(!toks.empty())
	{
		tok_chain some_toks;

		// fetches, pops & pushes the front-most token in 'tok_chain':
		string s = toks.front();
		toks.pop_front();
		some_toks.push_back(s);

		if(s=="(")
		{
			// balance is the number of yet un-closed parentheses
			int balance = 1;

			while(!toks.empty())
			{
				// fetches, pops & pushes the front-most token in 'tok_chain': (repeated code)
				s = toks.front();
				toks.pop_front();
				some_toks.push_back(s);

				if(s=="(")
					balance++;
				else if(s==")")
					balance--;

				if(!balance)
					break;
			}

			// balance = 0 means the expression is balanced
			if(balance)
				throw (string)("Missing closing bracket.");
		}
		else if(s==")")
			throw (string)("Missing opening bracket.");

		// push fragment
		if(!some_toks.empty())
			frags.push_back(some_toks);
	}

	return frags;
}

// function prototypes (local)
inline void push_string(string &, tok_chain &);
inline void fixChar(char &);

tok_chain Tokenize(const char *sp)
{
	tok_chain tokens;
	string temp;
	bool inString = false;

	for(char c = *sp, prevChar = '\0' ; c ; c = *++sp )
	{
		#define isBindingSymbol(C) ( C=='(' || C==')' || C=='{' || C=='}' )
		#define isAlphaNumeric(C) ( ((C>='0')&&(C<='9')) || (C>='A'&&C<='Z') || (C>='a'&&C<='z') )
		#define isPrintableASCII(C) ( ((C>=32)&&(C<=126)) || (C=='\t')  )

		if(isPrintableASCII(c))
		{
			if(isBindingSymbol(c))
			{
				push_string(temp, tokens);
				temp = c;
				push_string(temp, tokens);
			}
			else
			{
				fixChar(c);

				if(isAlphaNumeric(prevChar) != isAlphaNumeric(c))
					push_string(temp, tokens);

				temp += c;
				prevChar = c;
			}
		}

		#undef isBindingSymbol
		#undef isAlphaNumeric
		#undef isPrintableASCII

		else
			throw (string)("Non-printable ASCII character(" + cons((UC)(c)) 
				+ ":" + cons((UI)((UC)(c))) + ") detected.");
	}
	push_string(temp, tokens);

	return tokens;
}

inline void push_string(string &s, tok_chain &l)
{
	trim(s, ' ');
	if(s.length())
		l.push_back(s);
	s = "";
}

inline void fixChar(char &c)
{
	// tab => space
	if(c=='\t')
		c = ' ';
	// ' => "
	else if(c=='\'')
		c = '\"';
	// newline => ;
	else if(c=='\n')
		c = ';';
}
