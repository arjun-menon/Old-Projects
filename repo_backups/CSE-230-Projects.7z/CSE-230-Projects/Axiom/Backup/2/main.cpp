
#include "common.h"

void eval(const char *str)
{
	try
	{
		tok_chain k = Tokenize(str);
		cout<<endl<<k.size()<<" tokens:"<<endl;
		for(tok_chain::const_iterator i = k.begin(); i!=k.end(); i++)
			cout<<*i<<endl;
		
		frag_chain c = Fragmentize(k);
		cout<<endl<<c.size()<<" fragments:"<<endl;
		for(frag_chain::const_iterator i = c.begin(); i!=c.end(); i++) {
			for(tok_chain::const_iterator j = i->begin(); j!=i->end(); j++)
				cout<<*j;
			cout<<endl;
		}
	}
	catch(string e)
	{
		cout<<e;
	}
}

int main()
{
	cout<<"AXIOM-REPL: "<<endl;

	for(string input; true; )
	{
		cout<<"\n> ";
		getline(cin, input);

		if(input=="quit")
			break;
		else
			eval(input.c_str());
	}

	return 0;
}
