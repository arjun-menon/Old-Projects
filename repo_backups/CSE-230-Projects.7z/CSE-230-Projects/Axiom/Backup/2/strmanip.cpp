
#include "common.h"

void trim(char *s, const char T)
{
	/* removes all characters(T) from 
	   left & right sides of a string. */

	int l, r;

	// count T's in left side
	for(l=0; *s==T; s++)
		l++;

	// count T's at right side and 
	// shift string to the left
	for(r=0; *s; s++) {
		r = (*s==T) ? r+1:0;
		s[-l] = *s;
	}

	s[-l-r] = '\0';
}

void trim(string &s, const char T)
{
	// overloaded version of trim(char *s, const char T)
	// for the C++ string object argument

	if(!s.length())
		return;

	char *str = new char[s.length()+1];
	if(str==NULL)
		throw FATAL;

	strcpy(str, s.c_str());
	trim(str, T);
	s = str;

	delete [] str;
}
