/* 
 * File:   chario.cpp
 * Author: Arjun G. Menon
 * 
 * Created on January 1, 2009, 5:11 PM
 */

#include "main.hpp"

/*******************.
| Service Functions |
\*******************/

void co_print(charOutput *co, const string &str)
{
    const char *sp = str.c_str();

    while(*sp)
        co->put(*sp++);
}

/*****************************.
| File charI/O implementation |
\*****************************/

// fileInput

fileInput::fileInput(const string &file_name)
{
    file.open(file_name.c_str());

    if(!ok())
        throw (string)("File not found.");
}

bool fileInput::ok()
{
    return ( file.good() && (!file.eof()) );
}

char fileInput::get()
{
    if(ok())
        return (char)(file.get());
    else
        return '\0';
}

// fileOutput

fileOutput::fileOutput(string file_name)
{
    file.open(file_name.c_str());

    if(!ok())
        throw (string)("Unable to create file for writing.");
}

bool fileOutput::ok()
{
    return ( file.good() && (!file.eof()) );
}

void fileOutput::put(char c)
{
    if(ok())
        file.put(c);
}

/*******************************.
| String charI/O implementation |
\*******************************/

// stringInput

stringInput::stringInput(const string &s) : str(s)
{
    i = 0;
}

char stringInput::get()
{
    return str[i++];
}

bool stringInput::ok()
{
    return (i <= str.length());
}

// stringOutput

stringOutput::stringOutput()
{
    str = "";
}

void stringOutput::put(const char c)
{
    str += c;
}

bool stringOutput::ok()
{
    return true;
}

string & stringOutput::get_str()
{
    return str;
}

void stringOutput::clear()
{
    str = "";
}

