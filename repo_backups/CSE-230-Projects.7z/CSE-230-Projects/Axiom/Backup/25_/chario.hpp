
class charInput
{
    // function get() retrieves a character
    // ok() tells if it's ok to call get()

public:
    virtual char get() = 0;
    virtual bool ok() = 0;
};

class charOutput
{
    // function put() retrieves a character
    // ok() tells if it's ok to call put()
    
public:
    virtual void put(const char) = 0;
    virtual bool ok() = 0;
};

// Service functions

void co_print(charOutput *co, const string &s);

// File charI/O classes

class fileInput : public charInput
{
private:
    ifstream file;

public:
    fileInput(const string &file_name);

    char get();
    bool ok();
};

class fileOutput : public charOutput
{
private:
    ofstream file;

public:
    fileOutput(string file_name);

    void put(const char c);
    bool ok();
};

// String charI/O classes

class stringInput : public charInput
{
private:
    const string str;
    unsigned int i;

public:
    stringInput(const string &s);

    char get();
    bool ok();
};

class stringOutput : public charOutput
{
private:
    string str;

public:
    stringOutput();

    void put(const char c);
    bool ok();

    string & get_str();
    void clear();
};

