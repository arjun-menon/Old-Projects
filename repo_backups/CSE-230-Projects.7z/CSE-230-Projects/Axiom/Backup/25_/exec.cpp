
#include "main.hpp"

string exec(const string &str)
{
	stringInput si(str);

	string boo(charInput &xci);

	return boo(si);
}
