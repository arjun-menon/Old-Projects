/*
 *     Omnicron
 *       ----
 *   Arjun G. Menon
 *
 */

#include <iostream>
#include <string>

int main()
{
	std::cout<<"\nOmnicron:"<<std::endl;

    // exec function prototype:
    std::string exec(const std::string &str);

    // to hold user input
    std::string input = "";

    while(true)
    {
        std::cout<<"\n> ";
        getline(std::cin, input);

        if(input=="quit")
            break;
        else
			std::cout<<exec(input);
    }

    return 0;
}
