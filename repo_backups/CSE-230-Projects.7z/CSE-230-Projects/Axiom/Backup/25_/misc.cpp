
#include "main.hpp"

void trim(string &str, const string to_remove)
{  
    // trim leading & trailing 'to_remove'
    size_t startpos = str.find_first_not_of(to_remove);
    size_t endpos = str.find_last_not_of(to_remove);

    // if empty or all 'to_remove' return an empty string otherwise trim
    str = (( string::npos == startpos ) || ( string::npos == endpos)) ? "" : 
        str.substr( startpos, endpos-startpos+1 );
}

bool isPrintableASCII(char C)
{
	return ( ((C>=32)&&(C<=126)) || (C=='\t')  );
}

bool isBindingSymbol(char C)
{
	return ( C=='(' || C==')' || C=='{' || C=='}' );
}

bool isNumeric(char C)
{
	return ( (C>='0') && (C<='9') );
}

bool isAlphaNumeric(char C)
{
	return ( isNumeric(C) || (C>='A'&&C<='Z') || (C>='a'&&C<='z') );
}

bool isIdChar(char C)
{
	return ( isAlphaNumeric(C) || (C=='_') );
}

void convertEquivalentChar(char &c)
{
	/* converts equivalent characters */

	// tab => space
	if(c=='\t')
		c = ' ';
	// ' => "
	else if(c=='\'')
		c = '\"';
	// newline => ;
	else if(c=='\n')
		c = ';';
}
