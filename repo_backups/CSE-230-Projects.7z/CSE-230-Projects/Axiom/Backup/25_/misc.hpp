
void trim(string &str, const string to_remove = " \t");
bool isPrintableASCII(char C);
bool isBindingSymbol(char C);
bool isNumeric(char C);
bool isAlphaNumeric(char C);
bool isIdChar(char C);
void convertEquivalentChar(char &c);
