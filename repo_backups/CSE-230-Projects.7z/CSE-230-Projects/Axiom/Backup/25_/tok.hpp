
class Tokens
{
private:
	deque<string> toks;
	void push_token(string &s);
	string display(bool linear);

public:
	Tokens(charInput &in);
	string toString() { return display(true); }
	string toString2() { return display(false); }
};

class NonPrintableASCIIcharException : public userError
{
    public : NonPrintableASCIIcharException(char c) : 
    userError("Non-printable ASCII character(" + cons((UC)(c)) 
		+ ":" + cons((UI)((UC)(c))) + ") detected.") {}; 
};
