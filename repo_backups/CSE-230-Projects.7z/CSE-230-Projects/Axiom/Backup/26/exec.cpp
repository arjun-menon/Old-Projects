
#include "main.hpp"

string exec(const string &str)
{
	stringInput si(str);

	return (Tokens(si)).toString2();
}
