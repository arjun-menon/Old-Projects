
#include <string>
#include <sstream>
#include <fstream>

#include <vector>
#include <deque>
#include <list>
#include <map>

using namespace std;

/*******************.
| Exception Classes |
`*******************/

class userError : public exception
{
    // User Errors - caused by the user.
private:
    const string error_description;
public:
    virtual const char* what() const throw() { return error_description.c_str(); }
    userError(string err) : error_description((string)("Error: ")+err) {}
    ~userError() throw() {}
};

class fatalError : public exception
{
    // Fatal Errors - must never occur, invoked primarily 
	// when asserts fail - caused by the programmer.
private:
    const string error_description;
public:
    virtual const char* what() const throw() { return error_description.c_str(); }
    fatalError(string err) : error_description((string)("Fatal Error: ")+err) {}
    ~fatalError() throw() {}
};

/******.
| Misc |
`******/

typedef deque<string> tok_chain;

// returns the standard string representation of x
template <typename T> string cons(const T &x)
{
    stringstream s;
    s << x;
    return s.str();
}

/********.
| Macros |
`********/

#define UI unsigned int
#define UC unsigned char

#define ASSERT(X) if(!(X)) throw fatalError\
((string)("Assertion failure ( ")+(string)(#X)+(string)(" )"))

/******************.
| Project Headers  |
`******************/

#include "chario.hpp"
#include "misc.hpp"
#include "tok.hpp"
