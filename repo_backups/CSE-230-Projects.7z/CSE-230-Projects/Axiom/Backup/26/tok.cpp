
#include "main.hpp"

void Tokens::push_token(string &s)
{
	trim(s);
	if(s.length())
		toks.push_back(s);
	s = "";
}

string Tokens::display(bool linear)
{
	stringstream sout;
	if(!linear)
		sout<<endl<<toks.size()<<" tokens:"<<endl;
	for(tok_chain::const_iterator i = toks.begin(); i!=toks.end(); i++)
	{
		sout<<*i;
        
		if(!linear)
			sout<<endl;
	}
	return sout.str();
}

Tokens::Tokens(charInput &in)
{
	string temp;
	bool inString = false;

	for(char currentChar = in.get(), prevChar = '\0', prevChar2 = '\0', nextChar = '\0'; 
		in.ok() ; prevChar2 = prevChar, prevChar = currentChar, currentChar = nextChar)
	{
		nextChar = in.get();

		if(isPrintableASCII(currentChar))
		{
			convertEquivalentChar(currentChar);

			if(inString)
			{
				if(currentChar=='\"' && prevChar!='\\' // below for "\\"
				||(currentChar=='\"' && prevChar=='\\' && prevChar2=='\\'))
				{
					// string literal termination
					inString = false;
					temp += currentChar;
					push_token(temp);
				}
				else
					temp += currentChar;
			}
			else
			{
				// strings
				if(currentChar=='\"')
				{
					push_token(temp);
					inString = true;
					temp += currentChar;
				}

				 // standard seperators: space, tab, newline
				else if(currentChar==' ')
				{
					push_token(temp);
				}

				// parentheses & braces
				else if(isBindingSymbol(currentChar))
				{
					push_token(temp);
					temp = currentChar;
					push_token(temp);
				}

				// collect cohesive group of chars into single token
				else {
					if(!( 
						// seperate identifier literals fro non-id ones
						( isIdChar(prevChar) == isIdChar(currentChar) )
						// test for real number literals (example: 2.34)
						|| (isNumeric(prevChar) && currentChar=='.' && isNumeric(nextChar))
						|| (isNumeric(prevChar2) && prevChar=='.' && isNumeric(currentChar))
					))
						push_token(temp);

					temp += currentChar;
				}
			}
		}
		else throw NonPrintableASCIIcharException(currentChar);
	}
	push_token(temp);

	if(inString)
		throw userError("Unterminated string");
}
