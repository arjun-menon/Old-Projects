
#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
#include <functional>
#include <vector>
#include <deque>
#include <list>
#include <map>

using namespace std;

/********.
| Macros |
\********/

#define UI unsigned int
#define UC unsigned char
#define FATAL (string)("Fatal Error")
#define ASSERT(X) if(!(X)) throw FATAL
#define NOMEM (string)("Out of Memory"); // or std::bad_alloc

/**********.
| Typedefs |
\**********/

// NOTE !!! tok_chain = frag
typedef deque<string> tok_chain;
typedef list<tok_chain> frag_chain;

/************.
| Prototypes |
\************/

// lexer.cpp
tok_chain Tokenize(const char *sp);
frag_chain Fragmentize(deque<string> &toks);
void trim(string &str, const string to_remove = " \t");
string display_toks(const tok_chain &);
string display_frags(const frag_chain &);

/***********.
| Templates |
\***********/

template <typename T> string cons(T x)
{
	// construct string with generic x
	stringstream s;
	s << x;
	return s.str();
}
