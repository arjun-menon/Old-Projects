
#include "common.h"

class UserObjectClass
{
private:
	bool isNull;
	double val;
public:
	UserObjectClass()
	{
		val = 0;
		isNull = true;
	}
	UserObjectClass(double k)
	{
		val = k;
		isNull = false;
	}
	void setVal(double k)
	{
		val = k;
		isNull = false;
	}
	double getVal()
	{
		return val;
	}
	string toString()
	{
		if(isNull)
			return (string)("(null)");
		else
			return cons(val);
	}
};

// binary operators
map<string, float> bops;

void init_bops()
{
	bops["+"] = 1;
	bops["-"] = 1;
	bops["*"] = 2;
	bops["/"] = 2;
}

frag_chain::iterator findBinaryOperator(frag_chain &frags)
{
	frag_chain::iterator pos = frags.end();
	float max = 1000; // CHANGE THIS (later)

	for(frag_chain::iterator i = frags.begin(); i!=frags.end(); i++) {
		if(i->size() == 1) { // bop _must_ be a unit fragment
			if(bops.find(i->front())!=bops.end()) {
				if(bops[i->front()]<max) {
					pos = i;
					max = bops[i->front()];
				}
			}
		}
	}

	return pos; // this will return frags.end()
}

UserObjectClass eval(frag_chain frags); // PROTOTYPE (needed for recursion)

UserObjectClass applyBOP(string bop_name, frag_chain lhs, frag_chain rhs)
{
	UserObjectClass result, lhs_result, rhs_result;

	// always do lhs first, then rhs:
	lhs_result = eval(lhs);
	rhs_result = eval(rhs);

	if(bop_name == "+")
		result.setVal(lhs_result.getVal() + rhs_result.getVal());
	else if(bop_name == "-")
		result.setVal(lhs_result.getVal() - rhs_result.getVal());
	else if(bop_name == "*")
		result.setVal(lhs_result.getVal() * rhs_result.getVal());
	else if(bop_name == "/")
		result.setVal(lhs_result.getVal() / rhs_result.getVal());

	return result;
}

UserObjectClass eval(frag_chain frags)
{
	if(frags.size() < 1)
	{
		// frags is empty, so return null UserObj; this
		// happens either when there is a blank expr or ()
		return UserObjectClass(); // *** Base Case ***
	}
	else if(frags.size() == 1)
	{
		tok_chain toks = frags.front();

		if(toks.size() > 1)
		{
			// strip parentheses
			ASSERT(toks.front()=="(");
			ASSERT(toks.back()==")");
			toks.pop_front();
			toks.pop_back();

			// *** Recursive Call ***
			return eval(Fragmentize(toks));
		}
		else if(toks.size() == 1)
		{
			// we have reached a unit fragment *** Base Case ***
			return UserObjectClass(atof(toks.front().c_str()));
		}
		else
		{
			// empty token chain - must NEVER happen
			throw (string)("Fatal Error: Fragmentation fault");
		}
	}
	else // if(frags.size() > 1)
	{
		frag_chain::iterator pos;

		// search for binary operator
		if((pos = findBinaryOperator(frags)) != frags.end())
		{
			// found a binary operator
			frag_chain lhs_frags, rhs_frags;

			lhs_frags.splice(lhs_frags.begin(), frags, frags.begin(), pos);
			pos = frags.begin();
			rhs_frags.splice(rhs_frags.begin(), frags, ++pos, frags.end());

			// now applying binary operation - *** Expect Recursion ***
			return applyBOP(*(frags.begin()->begin()), lhs_frags, rhs_frags);
		}
		else
		{
			// perform function call
			throw (string)("Not implemented.\n"+display_frags(frags));
		}
	}
}

void exec(const char *str)
{
	try
	{
		init_bops();
		cout<<eval(Fragmentize(Tokenize(str))).toString();
	}
	catch(string e)
	{
		cout<<e;
	}
}

int main()
{
	cout<<"AXIOM-REPL: "<<endl;

	for(string input; true; )
	{
		cout<<"\n> ";
		getline(cin, input);

		if(input=="quit")
			break;
		else
			exec(input.c_str());
	}

	return 0;
}
