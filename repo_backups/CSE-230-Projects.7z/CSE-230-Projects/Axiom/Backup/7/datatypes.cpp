
#include "common.h"

/*

Datatypes:
==========
These are the building blocks of the language.
There are 7 primitive datatypes: 5 basic & 2 compound.

Basic:
------
null  - 11  */  #define DATATYPE_null 11  /*
byte  - 22  */  #define DATATYPE_byte 22  /*
int   - 44  */  #define DATATYPE_int  44  /*
real  - 66  */  #define DATATYPE_real 66  /*
str   - 77  */  #define DATATYPE_str  77  /*

Compound:
---------
pair  - 88  */  #define DATATYPE_pair 88  /*
list  - 99  */  #define DATATYPE_list 99  /*

*/

class UserObjectClass
{
private:
	char typeID;
	void *value;
public:
	UserObjectClass();
	UserObjectClass(string autoSet_content);
	~UserObjectClass();
	void autoSet(string content);
	UserObjectClass applyMethod(string method, UserObjectClass argument, string &error);
};

class dataType_real
{
private:
	double val;
public:
	dataType_real()
	{
		val = 0;
	}
	dataType_real(double v)
	{
		val = v;
	}
	dataType_real(string vs)
	{
		val = atof(vs.c_str());
	}
};

UserObjectClass::UserObjectClass()
{
	typeID = 11; // null
	value = NULL;
}

UserObjectClass::UserObjectClass(string autoSet_content)
{
	UserObjectClass();
	autoSet(autoSet_content);
}

UserObjectClass::~UserObjectClass()
{
	if(value != NULL)
		delete value;
}

void UserObjectClass::autoSet(string content)
{
	typeID = 66;
	value = new dataType_real(content);
}

UserObjectClass UserObjectClass::applyMethod(string method, UserObjectClass argument, string &error)
{
	UserObjectClass result;
	error = "";

	return result;
}

// Turning off dataType macros...
#undef DATATYPE_null
#undef DATATYPE_byte
#undef DATATYPE_int
#undef DATATYPE_real
#undef DATATYPE_str
#undef DATATYPE_pair
#undef DATATYPE_list
