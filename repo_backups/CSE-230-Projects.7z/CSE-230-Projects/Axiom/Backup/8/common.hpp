
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <list>
#include <map>
// C Library:
#include <cstring>
#include <cmath>

using namespace std;

/**********************************************.
| Common Classes, templates, typedefs & macros |
\**********************************************/

// Common Classes
class iErr : public exception
{
	/*
	Normal Errors are due to the user's fault.
	Fatal Errors are due to the programmer's fault.
	*/
private:
	const string error_description;
public:
	iErr(string err_description, bool isFatal = false) : 
	  error_description( (isFatal ? (string)("Fatal "):(string)("")) 
		  + (string)("Error: ") + err_description) {}
	iErr(iErr &copy) : error_description(copy.error_description) {}
	virtual const char* what() const throw() { return error_description.c_str(); }
};

// Common Templates
template <typename T> string cons(T x)
{
	// construct string with generic x
	stringstream s;
	s << x;
	return s.str();
}

// Common Typedefs
typedef deque<string> tok_chain; // NOTE !!! tok_chain = fragment
typedef list<tok_chain> frag_chain;

// Common Macros
#define UI unsigned int
#define UC unsigned char
#define ASSERT(X) if(!(X)) throw iErr\
((string)("Assertion failure ( ")+(string)(#X)+(string)(" )"), true);

/*****************************.
| Source File Header Includes |
\*****************************/

// lexer.cpp
tok_chain Tokenize(const char *sp);
frag_chain Fragmentize(deque<string> &toks);
void trim(string &str, const string to_remove = " \t");
string display_toks(const tok_chain &);
string display_frags(const frag_chain &);

#include "datatypes.hpp"  // datatypes.cpp
