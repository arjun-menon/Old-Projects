
#include "common.hpp"

class dataType_real
{
private:
	// const becuase dataType_real is immutable
	const double val;
	// this function defines binary operations on real numbers
	static double applyMethod(const dataType_real &obj, const string &method, const dataType_real &arg)
	{
		if(method=="add")
			return obj.val + arg.val;
		else if(method=="sub")
			return obj.val - arg.val;
		else if(method=="mul")
			return obj.val * arg.val;
		else if(method=="div")
			return obj.val / arg.val;
		else
			throw iErr("Non-existant method invoked.");
	}
	// this function defines unary operations on real numbers
	static double applyMethod(const dataType_real &obj, const string &method)
	{
		if(method=="abs")
			return fabs(obj.val);
		else if(method=="floor")
			return floor(obj.val);
		else if(method=="ceil")
			return ceil(obj.val);
		else
			throw iErr("Non-existant method invoked.");
	}
public:
	/*
	The only way to set "val" is by using the constructor.
	This means, once "val" is set, it cannot be changed.
	*/
	dataType_real() : val(0) {}
	dataType_real(double v) : val(v) {}
	dataType_real(string vs) : val(atof(vs.c_str())) {}
	dataType_real(const dataType_real &obj, const string &method, 
		const dataType_real &arg) : val(applyMethod(obj, method, arg)) {}
	dataType_real(const dataType_real &obj, const string &method) : val(applyMethod(obj, method)) {}

	string toString()
	{
		// Convert to string
		return cons(val);
	}
};

/*

Datatypes:
==========
These are the building blocks of the language.
There are 7 primitive datatypes: 5 basic & 2 compound.

Basic:
------
null  - 11
byte  - 22  (char)
int   - 44  (long)
real  - 66  (double)
str   - 77

Compound:
---------
pair  - 88
list  - 99

*/

// Macros for each datatype...
#define DATATYPE_null 11
#define DATATYPE_byte 22
#define DATATYPE_int  44
#define DATATYPE_real 66
#define DATATYPE_str  77  
#define DATATYPE_pair 88
#define DATATYPE_list 99

UserObjectClass::UserObjectClass()
{
	typeID = DATATYPE_null;
	value = NULL;
}

UserObjectClass::UserObjectClass(UserObjectClass &copy)
{
	typeID = copy.typeID;
	value = copy.value; // FIX THIS - copy.value will be destroyed
}

// initialize object using string content
UserObjectClass::UserObjectClass(string content)
{
	typeID = DATATYPE_real;
	value = new dataType_real(content);
}

// initialize with results of 'object.method(argument)'
UserObjectClass::UserObjectClass(const UserObjectClass &obj, const string &method, const UserObjectClass &arg)
{
	if(obj.typeID == DATATYPE_real)
	{
		typeID = DATATYPE_real;
		value = new dataType_real(*((dataType_real *)(obj.value)),method,*((dataType_real *)(arg.value)));
	}
	else
		throw iErr("Method invokation on null object.");
}

// initialize with results of 'object.method'
UserObjectClass::UserObjectClass(const UserObjectClass &obj, const string &method)
{
	if(obj.typeID == DATATYPE_real)
	{
		typeID = DATATYPE_real;
		value = new dataType_real(*((dataType_real *)(obj.value)),method);
	}
	else
		throw iErr("Method invokation on null object.");
}

UserObjectClass::~UserObjectClass()
{
	if(value != NULL) {
		cout<<"Destroying: "<<toString()<<endl;
		delete value;
	}
}

void UserObjectClass::swap(UserObjectClass &x)
{
	// XOR swap 'typeID'
	typeID ^= x.typeID;
	x.typeID ^= typeID;
	typeID ^= x.typeID;

	// swap 'value'
	void *temp = value;
	value = x.value;
	x.value = temp;
}

string UserObjectClass::toString()
{
	if(typeID == DATATYPE_real)
	{
		dataType_real *current_value = (dataType_real *) value;
		return current_value->toString();
	}
	else
		return "null";
}

// Turning off datatype macros...
#undef DATATYPE_null
#undef DATATYPE_byte
#undef DATATYPE_int
#undef DATATYPE_real
#undef DATATYPE_str
#undef DATATYPE_pair
#undef DATATYPE_list
