
class UserObjectClass
{
private:
	char typeID;
	void *value;
public:
	UserObjectClass();
	UserObjectClass(UserObjectClass &copy);
	UserObjectClass(string content);
	UserObjectClass(const UserObjectClass &obj, const string &method, const UserObjectClass &arg);
	UserObjectClass(const UserObjectClass &obj, const string &method);
	~UserObjectClass();
	void swap(UserObjectClass &x);
	string toString();
};
