
#include "common.hpp"

class UserObj
{
private:
	bool isNull;
	double val;
public:
	UserObj()
	{
		val = 0;
		isNull = true;
	}
	UserObj(double k)
	{
		val = k;
		isNull = false;
	}
	void setVal(double k)
	{
		val = k;
		isNull = false;
	}
	double getVal()
	{
		return val;
	}
	string toString()
	{
		if(isNull)
			return (string)("(null)");
		else
			return cons(val);
	}
};

// binary operators
map<string, float> bops;

void init_bops()
{
	bops["+"] = 1;
	bops["-"] = 1;
	bops["*"] = 2;
	bops["/"] = 2;
	bops["**"] = 3;
}

frag_chain::iterator findBinaryOperator(frag_chain &frags)
{
	frag_chain::iterator pos = frags.end();
	map<string, float>::const_iterator bop = bops.begin();
	// check if bops is empty
	if(bop==bops.end())
		return pos;

	float max;
	// calculate max, whose value is greater than that of 
	// the binary operator with the greatest mapped value.
	for(max = (bop++)->second; bop!=bops.end(); bop++)
		if(bop->second > max)
			max = bop->second;
	max++;

	// Now find the binary operator with *lowest* precedence:
	for(frag_chain::iterator i = frags.begin(); i!=frags.end(); i++) {
		if(i->size() == 1) { // bop must be a unit fragment
			if((bop = bops.find(i->front()))!=bops.end()) {
				if(bop->second < max) {
					pos = i;
					max = bop->second;
				}
			}
		}
	}

	return pos;
}

UserObj eval(frag_chain frags); // PROTOTYPE (needed for recursion)

UserObj applyBOP(string bop_name, frag_chain lhs, frag_chain rhs)
{
	UserObj result, lhs_result, rhs_result;

	// always do lhs first, then rhs:
	lhs_result = eval(lhs);
	rhs_result = eval(rhs);

	if(bop_name == "+")
		result.setVal(lhs_result.getVal() + rhs_result.getVal());
	else if(bop_name == "-")
		result.setVal(lhs_result.getVal() - rhs_result.getVal());
	else if(bop_name == "*")
		result.setVal(lhs_result.getVal() * rhs_result.getVal());
	else if(bop_name == "/")
		result.setVal(lhs_result.getVal() / rhs_result.getVal());

	return result;
}

UserObj eval(frag_chain frags)
{
	if(frags.size() < 1)
	{
		// frags is empty, so return null UserObj; this
		// happens either when there is a blank expr or ()
		return UserObj(); // *** Base Case ***
	}
	else if(frags.size() == 1)
	{
		tok_chain toks = frags.front();

		if(toks.size() > 1)
		{
			// strip parentheses
			ASSERT(toks.front()=="(");
			ASSERT(toks.back()==")");
			toks.pop_front();
			toks.pop_back();

			// *** Recursive Call ***
			return eval(Fragmentize(toks));
		}
		else if(toks.size() == 1)
		{
			// we have reached a unit fragment *** Base Case ***
			return UserObj(atof(toks.front().c_str()));
		}
		else
		{
			// empty token chain - must NEVER happen
			throw iErr("Fragmentation fault", true);
		}
	}
	else // if(frags.size() > 1)
	{
		frag_chain::iterator pos;

		// search for binary operator
		if((pos = findBinaryOperator(frags)) != frags.end())
		{
			// found a binary operator
			frag_chain lhs_frags, rhs_frags;

			lhs_frags.splice(lhs_frags.begin(), frags, frags.begin(), pos);
			pos = frags.begin();
			rhs_frags.splice(rhs_frags.begin(), frags, ++pos, frags.end());

			// now applying binary operation - *** Expect Recursion ***
			return applyBOP(*(frags.begin()->begin()), lhs_frags, rhs_frags);
		}
		else
		{
			// perform function call
			throw iErr("Not implemented.\n"+display_frags(frags));
		}
	}
}

void exec(const char *str)
{
	try
	{
		init_bops();
		cout<<eval(Fragmentize(Tokenize(str))).toString();
	}
	catch(exception &e) {
		cout<<e.what();
	}
	catch(...) {
		cout<<iErr("Unhandled Exception.", true).what()<<endl;
	}
}

int main()
{
	string e;
	UserObjectClass a("5.1");
	UserObjectClass b("-3.2");
	UserObjectClass c(a,"mul",b);
	//c = UserObjectClass(c,"add",UserObjectClass("1"));
	UserObjectClass d(a,"ceil");
	cout<<"\nValues:"<<endl;
	cout<<a.toString()<<endl;
	cout<<b.toString()<<endl;
	cout<<c.toString()<<endl;
	cout<<d.toString()<<endl;

	cout<<"\nAXIOM-REPL: "<<endl;

	for(string input; true; )
	{
		cout<<"\n> ";
		getline(cin, input);

		if(input=="quit")
			break;
		else
			exec(input.c_str());
	}

	return 0;
}
