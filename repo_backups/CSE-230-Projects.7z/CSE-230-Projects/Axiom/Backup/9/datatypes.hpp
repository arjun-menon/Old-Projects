
class UserObjectClass
{
private:
	char typeID;
	void *value;
public:
	UserObjectClass();  // default constructor
	UserObjectClass(const UserObjectClass &copy);  // copy constructor
	UserObjectClass & operator=(const UserObjectClass &rhs);  // assignment operator
	void swap(UserObjectClass &x);  // swap
	~UserObjectClass();  // destructor

	// construct object with the result of the function call 'obj.method(arg)'
	UserObjectClass(const string &method, const UserObjectClass &obj, const UserObjectClass &arg);
	// construct object from string
	UserObjectClass(const string &content);
	// convert object to string
	string toString();
};

class methodNotFoundException : public genericException 
{
	public : methodNotFoundException(string method_name) : 
	genericException("Method \""+method_name+"\" is not a part of this object.", false) {}; 
};
