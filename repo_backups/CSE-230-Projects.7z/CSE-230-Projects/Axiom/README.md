This is an interpreter I wrote in 2008 for my final project in [a course on C++](http://www.cs.sunysb.edu/undergrad/cse_courses/cse230.html) that I took at [Stony Brook](http://www.stonybrook.edu/).

Verbatim copy of description submitted with assingment:

1) When you compile & run the program, the first thing you will see is
"AXIOM-REPL" and an angle-bracket prompt. It is a Read-Eval-Print-Loop
(REPL). Here you can type in one-line expression that will be
evaluated upon pressing the return button. Once the expression is
evaluated, the result of the evaluation is printed on the next; which
could generally be a single number, a pair or a list. To quit the
program type in "quit" and hit return.

2) Examples of simple expression: When you type an expression
consisting on numbers like "(2.3+4.5)*(7.8-3.6)" and hit enter the
result (28.56) will be printed. Axiom supports strings. Putting some
text in semicolon turns the text into a string. Like numbers, strings
can be added too. ("a"+"b" will result in "ab", note: adding strings
only works on the updated version of my axiom attached with this mail)

3) An empty set of parentheses "()" results in "(null)". Several
numbers/string/expressions placed together results in a list being
created in which each element corresponds to the evaluated result of
each element. Example "4.6 3 (4+5) 7 'hello' 6 " will result in the
following list: "(4.6, 3, 9, 7, hello, 6)". Writing "2 = 3" will
result in a pair "(2 => 3)".

3) There are 5 datatypes in Axiom:
3.a: null - Null object. Cannot hold any data but is still a datatype.
3.b: num - Real number object. Stored internally as the C/C++ double datatype.
3.c: str - String object. Stored internally as a C++ STL string object.
3.d: pair - Two objects of any types can be put in key-value pairs.
The left element is called the key & the right element is called the
value.
3.3: list - Any number of objects of any types can be collected into a list.
 You might ask why a special datatype pair when lists can be used to
hold 2 elements. Well, at this point the program does not make use of
the pair facility yet. The intention/purpose of this datatype is to
hold variables; ie. x=7 will result in a pair (x=>7) being inserted
onto a 'reference list'. Later when the variable is needed, the
interpreter looks up on the reference list to find the value of 'x'.
Also, when new assignments are made, the new pair while being inserted
onto the list, does not undergo a blind push_back operation. Instead
the list, seeing that a pair is being inserted searches the itself for
another pair with the same key; if one exists the new pair simply
overwrites the previous one. Pairs could also be used to efficiently
implement associative arrays.

4) Everything is an object. Expression are objects, datatypes are
objects, e.t.c. You can access the member functions inside each object
by using the (".") symbol a.k.a member access operator. For example:
"5.neg" will result in -5. Similarly "abc".len will reuslt in 3, which
is the length of the string. As you can see here the "neg" member
function of numbers produces the negative value of a certain object
and the "len" member function of strings produces the length of the
string. In the updated version of axiom attached with this e-mail,
numbers have many more membrr functions like sin, cos, tan, asin,
acos, atan,.., split. ( The slit function performs modf and stores the
result in a string. Example: "3.45.split" -> "(3, 0.45)". The null
object also has member functions. Depending on the member/operator the
null object will act differently. The member "num" will result in a
number object initialized to 0 being returned. Similarly str will
return an empty string. If the null cannot recognize the member, it
will flip over the member access operation and apply it to the
argument. (note: only works on the updated version of axiom attached
with this mail)

5) Debug mode: To track the various objects beinn created and
destroyed during evaluation, you can switch on the debug option. To do
this go to the last line in "common.h" and de-comment the definition
"SHOW_DEBUG_MESSAGES". Once the macro is enabled, a message will be
printed on the screen each time an object is constructed, copied or
destroyed. This can be useful for debugging to know what's going on in
the program during expression evaluation.