/*
 *     CSE 230 HW 5
 *
 *  Written by Arjun G. Menon
 *
 *             arjungmenon@gmail.com
 *         www.arjungmenon.com
 *
 */

#include <iostream>
#include <string>

int main()
{
    std::cout<<"\nAXIOM-REPL: "<<std::endl;

    // exec function prototype:
    std::string exec(const std::string &str);

    // to hold user input
    std::string input = "";

    while(true)
    {
        std::cout<<"\n> ";
        getline(std::cin, input);

        if(input=="quit")
            break;
        else
            std::cout<<exec(input);
    }

    return 0;
}
