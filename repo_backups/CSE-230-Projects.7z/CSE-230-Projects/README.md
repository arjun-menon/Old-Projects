**Axiom** is HW 5. It's a nifty desktop calculator that was supposed to grow up and become an interpreter.

(HW 1 and 2 are not interesting, so they're not included here.)