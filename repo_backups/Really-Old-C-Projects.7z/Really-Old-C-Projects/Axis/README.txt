An interpreter I wrote in high school. It was written primarily over 2005 and 2006.

It's terrible. (TM)